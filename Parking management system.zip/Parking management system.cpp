//🚗 Parking Management System
/*🔍 Overview: A Smart Parking Management System automates parking lot operations.
It helps monitor parking slot availability, assigns spots, 
calculates parking time and fees, and tracks vehicle details.

#Features Included:
1.Parking a vehicle.
2.Remove a vehicle.
3.Show parking lot status.
4.Exit vehicle.
5.Parking fee calculation.*/y


#include <iostream>
#include <vector>
#include <ctime>
#include <iomanip>
#include <fstream>
#include <map>
#include <memory>

using namespace std;

// 🚗 Vehicle class
class Vehicle {
public:
    string number;
    string type;
    time_t entryTime;

    Vehicle(const string& num, const string& t) : number(num), type(t) {
        time(&entryTime);
    }

    double calculateFee(time_t exitTime) const {
        double duration = difftime(exitTime, entryTime) / 60; // minutes
        double rate;

        if (type == "car")
            rate = 2.0;
        else if (type == "bike")
            rate = 1.0;
        else if (type == "bus")
            rate = 3.5;
        else
            rate = 2.0; // default

        return duration * rate;
    }

    string getEntryTimeString() const {
    string timeStr = ctime(&entryTime);
    timeStr.pop_back(); // remove trailing newline '\n'
    return timeStr;
    }
};

// 🅿️ Parking slot class
class ParkingSlot {
public:
    int slotNumber;
    bool occupied;
    unique_ptr<Vehicle> vehicle;

    ParkingSlot(int number) : slotNumber(number), occupied(false), vehicle(nullptr) {}
};

// 🏢 Parking lot class
class ParkingLot {
private:
    vector<ParkingSlot> slots;
    map<string, int> vehicleMap; // vehicleNumber -> slotIndex

public:
    ParkingLot(int size) {
        for (int i = 0; i < size; ++i) {
            slots.emplace_back(i + 1);
        }
    }

    bool isValidType(const string& type) const {
        return (type == "car" || type == "bike" || type == "bus");
    }

    void parkVehicle(const string& number, const string& type) {
        if (!isValidType(type)) {
            cout << "❌ Invalid vehicle type. Use 'car', 'bike', or 'bus'.\n";
            return;
        }

        if (vehicleMap.find(number) != vehicleMap.end()) {
            cout << "❌ Vehicle number already parked.\n";
            return;
        }

        for (auto& slot : slots) {
            if (!slot.occupied) {
                slot.vehicle = make_unique<Vehicle>(number, type);
                slot.occupied = true;
                vehicleMap[number] = slot.slotNumber - 1;
                cout << "✅ Vehicle parked at slot #" << slot.slotNumber << "\n";
                return;
            }
        }
        cout << "❌ No parking slots available.\n";
    }

    void removeVehicle(const string& number) {
        auto it = vehicleMap.find(number);
        if (it == vehicleMap.end()) {
            cout << "❌ Vehicle not found.\n";
            return;
        }

        int idx = it->second;
        ParkingSlot& slot = slots[idx];
        Vehicle* v = slot.vehicle.get();

        time_t exitTime;
        time(&exitTime);

        int totalMinutes = static_cast<int>(difftime(exitTime, v->entryTime) / 60);
        int hours = totalMinutes / 60;
        int minutes = totalMinutes % 60;

        double fee = v->calculateFee(exitTime);

        cout << "\n🚗 Vehicle Number: " << v->number << "\n";
        cout << "Type: " << v->type << "\n";
        cout << "Entry Time: " << v->getEntryTimeString() << "\n";
        cout << "Exit Time: " << ctime(&exitTime);
        cout << "🕒 Duration: " << hours << " hours and " << minutes << " minutes\n";
        cout << "💰 Parking Fee: $" << fixed << setprecision(2) << fee << "\n";

        // Save to file
        ofstream file("parking_data.csv", ios::app);
        if (file.is_open()) {
            file << v->number << "," << v->type << "," << v->getEntryTimeString() << "," << ctime(&exitTime) << "," << fee << "\n";
            file.close();
        }

        // Free memory and clear slot
        slot.vehicle.reset();
        slot.occupied = false;
        vehicleMap.erase(it);

        cout << "👋 Take care, safe journey!\n";  // ✅ Message added here
    }

    void showStatus() const {
        cout << "\n📊 Parking Lot Status:\n";
        for (const auto& slot : slots) {
            cout << "Slot #" << slot.slotNumber << ": ";
            if (slot.occupied) {
                cout << "Occupied by [" << slot.vehicle->number << " - " << slot.vehicle->type
                     << "] (Entry: " << slot.vehicle->getEntryTimeString() << ")\n";
            } else {
                cout << "Empty\n";
            }
        }
    }
};

// 🔁 Main menu
int main() {
    const int LOT_SIZE = 5;
    ParkingLot lot(LOT_SIZE);
    int choice;
    string number, type;

    do {
        cout << "\n🚗 Vehicle Parking Management System\n";
        cout << "1. 🅿️ Park Vehicle\n";
        cout << "2. ❌ Remove Vehicle\n";
        cout << "3. 📊 Show Parking Lot Status\n";
        cout << "4. 👋 Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Vehicle Number: ";
                cin >> number;
                cout << "Enter Vehicle Type (car/bike/bus): ";
                cin >> type;
                lot.parkVehicle(number, type);
                break;
            case 2:
                cout << "Enter Vehicle Number to Remove: ";
                cin >> number;
                lot.removeVehicle(number);
                break;
            case 3:
                lot.showStatus();
                break;
            case 4:
                cout << "👋 Exiting system. Goodbye!\n";
                break;
            default:
                cout << "❌ Invalid option.\n";
        }
    } while (choice != 4);

    return 0;
}